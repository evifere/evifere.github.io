$(document).ready (
function ()
 {
 
  $('#brixploder').brixploder({lives:1});
  
  
  
  
 });//fin ready
